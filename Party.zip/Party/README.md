# EZScript Christmas Party 2026 — RSVP

Mobile-friendly RSVP invitation for **EZScript Christmas Celebrations · Thursday, December 17, 2026 · Newport Beach, California**.
It's a static site for GitHub Pages. Every RSVP and every step of each visitor's journey is saved to a Google Sheet, which you can download as Excel.

```
index.html              ← the invitation + RSVP flow (GitHub Pages serves this)
assets/ezscript-logo.png
apps-script/Code.gs     ← backend that writes to the Google Sheet (not served; paste into Apps Script)
.nojekyll
```

---

## 1. Set up the Google Sheet (≈5 min)

1. Create a new Google Sheet, e.g. **"EZScript Christmas Party 2026 — RSVPs"**, using the company Google account that should own the data.
2. **Extensions → Apps Script**. Delete the sample code and paste in everything from `apps-script/Code.gs`. Save.
3. *(Optional)* To get an email for every new RSVP, set `NOTIFY_EMAIL` at the top of the script, e.g. `"events@ezscript.com"`.
4. Select **`setup`** in the function dropdown, then click **Run**. Approve the permission prompt.
   This creates three tabs: **Summary**, **RSVPs** and **Activity**.
5. **Deploy → New deployment →** type **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone** (required so guests can submit without a Google login)
6. Click **Deploy** and copy the **Web app URL**. It ends in `/exec`.
7. Paste that URL into `index.html`, near the top of the `<script>`:

   ```js
   const CONFIG = {
     ENDPOINT: "https://script.google.com/macros/s/XXXXXXXX/exec",
     EVENT_ID: "ezscript-christmas-2026"
   };
   ```

> **Changing the script later:** go to Deploy → Manage deployments → ✏️ → Version: *New version* → Deploy. The URL stays the same.

## 2. Publish on GitHub Pages

1. Create a repo, e.g. `ezscript-christmas-2026`, and upload these files to the root of the `main` branch.
2. Go to **Settings → Pages → Build and deployment**, choose Source: *Deploy from a branch*, branch `main`, folder `/ (root)`, then **Save**.
3. After about a minute the invitation is live at `https://<your-org>.github.io/ezscript-christmas-2026/`.
   *(Optional: in the same settings page, add a custom domain such as `party.ezscript.com`.)*

## 3. Per-client tracking links

Add URL parameters to the link you send each client. All of them are optional:

| Parameter | Purpose | Example |
|---|---|---|
| `invite` | Your ID for that guest/account. Recorded on every event and on the RSVP row | `ACME-001` |
| `name`   | Pre-fills the name field | `Jane%20Doe` |
| `email`  | Pre-fills the email field | `jane%40acme.com` |

```
https://<your-org>.github.io/ezscript-christmas-2026/?invite=ACME-001&name=Jane%20Doe&email=jane%40acme.com
```

**Making the links in bulk:** in a sheet with the invite ID in column A, the name in B and the email in C, use
`="https://<your-org>.github.io/ezscript-christmas-2026/?invite="&ENCODEURL(A2)&"&name="&ENCODEURL(B2)&"&email="&ENCODEURL(C2)`

## 4. What gets recorded

**RSVPs tab** has one row per guest, matched by email. If someone submits again, their existing row is updated and *Times Submitted* goes up by one.
Columns: Email · Name · Phone · Attending · Guests (incl. self) · Invite ID · First Submitted · Last Updated · Times Submitted · OS · Device · Browser · Visitor ID · Session ID

**Activity tab** has one row per event:

| Event | When |
|---|---|
| `page_view` | Invitation opened |
| `rsvp_started` | "RSVP Now" tapped |
| `step_view` | Each question / review screen shown |
| `validation_error` | Field rejected (name / email / phone). Records which field only, not the value |
| `answer` | Attendance or guest-count selected |
| `rsvp_submitted` | RSVP saved (written by the server) |
| `calendar_add` | Add to Calendar used (ios-native / google / ics / outlook-link …) |
| `edit_response` | Guest went back to change their answers |

Each event also records: Visitor ID (the same browser across visits), Session ID, Invite ID, email (once entered), OS, device type, browser, screen size, language, timezone, page URL and referrer.

**Summary tab** updates itself with: total responses, Yes / Maybe / No counts, confirmed and possible headcount, a funnel (opened → started → submitted → added to calendar, counted as unique visitors), the conversion rate, and RSVPs by device.

**To export to Excel:** in the Sheet, File → Download → Microsoft Excel (.xlsx).

## 5. Reliability & safety

- RSVPs are kept on the guest's device until they send successfully. If a guest submits with a weak or no mobile signal, it sends automatically when they're back online or reopen the page.
- The server checks every field again: email format, digits-only phone, Yes/No/Maybe, and 1–4 guests.
- Cells are protected against spreadsheet formula injection. A hidden honeypot field filters out simple bots.
- The endpoint is public, as any static-site form is. Keep the **Sheet** itself shared only with the events team, because it holds guests' contact details.
- Without an `ENDPOINT` the page still works, and events are printed to the browser console. This is useful for local testing.

## 6. Test locally

```bash
python3 -m http.server 8080   # then open http://localhost:8080/?invite=TEST-001
```
